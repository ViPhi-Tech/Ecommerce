export interface IUploadService {
    uploadFile(file: File): Promise<string>;
    destroyFile(files: File): Promise<string[]>;
}