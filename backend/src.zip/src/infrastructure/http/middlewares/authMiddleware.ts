// backend/src/infrastructure/http/middlewares/authMiddleware.ts
import { FastifyRequest, FastifyReply } from 'fastify';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'seu_jwt_secret_aqui';

export async function authenticate(request: FastifyRequest, reply: FastifyReply) {
  try {
    // Obter o token do cookie
    const token = request.cookies.access_token;
    
    if (!token) {
      return reply.code(401).send({ error: 'Authentication required' });
    }
    
    // Verificar o token
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded) {
      return reply.code(401).send({ error: 'Invalid or expired token' });
    }
    
    // Adicionar o usuário decodificado à requisição
    request.user = decoded as any;
    
  } catch (error) {
    return reply.code(401).send({ error: 'Authentication failed' });
  }
}

// Middleware para verificar roles
export function checkRole(roles: string[]) {
  return async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      // Primeiro autenticar
      await authenticate(request, reply);
      
      // Verificar se o usuário tem a role necessária
      const userRole = (request.user as any).role;
      
      if (!roles.includes(userRole)) {
        return reply.code(403).send({ error: 'Insufficient permissions' });
      }
      
    } catch (error) {
      return reply.code(403).send({ error: 'Permission check failed' });
    }
  };
}

// Adicionar tipos para TypeScript
declare module 'fastify' {
  interface FastifyRequest {
    user?: {
      userId: number;
      email: string;
      role?: string;
      [key: string]: any;
    };
  }
}