import { FastifyInstance } from 'fastify';
import authRoutes from './AuthRoutes';
import userRoutes from './UserRoutes';

export default async function handleRoutes(fastify: FastifyInstance) {
  // Registrar todas as rotas com o prefixo '/api'
  fastify.register(async (fastify) => {
    // Rotas públicas
    fastify.register(authRoutes, { prefix: '/auth' });
    
    fastify.get('/', async (request, reply) => {
      return { message: '' };
    });

    // Rotas protegidas
    fastify.register(async (fastify) => {
      // Adicionar middleware de autenticação para todas as rotas neste escopo
      fastify.addHook('onRequest', fastify.authenticate);
      
      // Todas as rotas aqui exigirão autenticação
      fastify.register(userRoutes, { prefix: '/user' });
      
    }, { prefix: '/protected' });

  }, { prefix: '/api' });
}