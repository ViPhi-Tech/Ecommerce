// backend/src/infrastructure/plugins/jwt.ts
import fp from 'fastify-plugin';
import jwt from 'jsonwebtoken';
import { FastifyRequest, FastifyReply } from 'fastify';

const JWT_SECRET = process.env.JWT_SECRET || 'seu_jwt_secret_aqui';

export default fp(async (fastify) => {
  // Decorador para verificar se o usuário está autenticado
  fastify.decorate('authenticate', async (request, reply) => {
    try {
      // Obter o token do cookie
      const token = request.cookies.access_token;
      
      if (!token) {
        return reply.code(401).send({ error: 'Authentication required' });
      }
      
      // Verificar o token
      const decoded = jwt.verify(token, JWT_SECRET);
      
      // Adicionar o usuário decodificado à requisição
      request.user = decoded as any;
      
    } catch (error) {
      return reply.code(401).send({ error: 'Authentication failed' });
    }
  });
  
  // Decorador para verificar roles
  fastify.decorate('checkRole', (roles: string[]) => {
    return async (request, reply) => {
      try {
        // Primeiro autenticar
        await fastify.authenticate(request, reply);
        
        // Verificar se o usuário tem a role necessária
        const userRole = (request.user as any).role;
        
        if (!roles.includes(userRole)) {
          return reply.code(403).send({ error: 'Insufficient permissions' });
        }
        
      } catch (error) {
        return reply.code(403).send({ error: 'Permission check failed' });
      }
    };
  });
});

// Adicionar tipos para TypeScript
declare module 'fastify' {
  interface FastifyInstance {
    authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
    checkRole: (roles: string[]) => (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }
  
  interface FastifyRequest {
    user?: {
      userId: number;
      email: string;
      role?: string;
      [key: string]: any;
    };
  }
}